# <img align="left" width="100" height="100" src="icon.png">Custom Title :{xmldoc2md-Title()} 
[![Build Status](https://dev.azure.com/charlesdevandiere/charlesdevandiere/_apis/build/status/charlesdevandiere.xmldoc2md?branchName=master)](https://dev.azure.com/charlesdevandiere/charlesdevandiere/_build/latest?definitionId=2&branchName=master)
[![Nuget](https://img.shields.io/nuget/v/XMLDoc2Markdown.svg?color=blue&logo=nuget)](https://www.nuget.org/packages/XMLDoc2Markdown)

{xmldoc2md-Back()}{xmldoc2md-BackIndex()}
- - -

{xmldoc2md-Body()}

- - -
{xmldoc2md-Back()}{xmldoc2md-BackIndex()}
